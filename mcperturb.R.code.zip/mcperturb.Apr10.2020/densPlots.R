##########################################################################################
# Function Name: densPlots  
#
# Function Descritption: 
# Takes in a matrix of variables, mean-centers each variable in the matrix, 
# calculates the desnisty probabilties for each variable, Outputs the density 
# lines on one plot for an overall comparison of each variables varability.
#
# Function Usage:
# densPlots(xmat, meanCent = TRUE, na.rm = TRUE)
#
# Function Arguments:
# xmat          A nummeric design matrix with the equal row lengths
# meanCent      Wether the columns of the matrix are mean cantered, default = TRUE
# na.rm         Whether to remove missing observations, if missing values will be filled 
#               with variables mean or median
# imputation    c("mean", "median")
# 
# Function Details:
# The densPlots function provides an oppertunity to observe the different patterns or 
# shared variances between one or multiple varaibles. When the variables are mean centered,
# they are ploted around the orgin but still keep have there original variance. There variances
# can be observed for model patterns and variables with sharded patterens can be found.
#
# Function Value:
# This function provides the opputunity for all variables in a matrix to be observed 
# on the same scale. This gives the user the opertunity to look for variables with shared 
# variances and the opertunity to look for underlining patterens of these shared variances. 
#
# Function Note:
# This function is made to plot the variables on one plot. In order for this function to 
# work, the length of each column vector must be the same. Therefore, if there exist a 
# missing value, then the whole observation must be removed. If the amount of observations 
# must be kept, then an imputation of the mean or median must occur. 
#
# Function Author(s)
# Ryan Zamora, Dr. Shuying Sun
#
# Function Regerences:
#
# Function See Also: (other functions)
#
# Examples:
#
# # Body dimensions data
# data(body_Dim)
# # X-matrix
# x = body_Dim[,c(10, 11, 16, 17, 21, 22, 24)]
# colnames(x) = c("shoulder", "chest", "bicep", "forearm", "wrist", "age", "height")
# densPlots(xmat=x, meanCent=TRUE)


##########################################################################################

densPlots = function(xmat = x, meanCent = TRUE, na.rm = TRUE)
{
  if(meanCent == TRUE)
  {
    new_xmat = apply(xmat,2,function(x)(x-mean(x, na.rm = TRUE)))
  }
  else{ 
    cat("You choose to make density plots without mean-centering the data. \n")
    cat("This is NOT a good. Please use meanCent = TRUE.  \n")
    new_xmat = xmat
  }
  
  dens_x = apply(new_xmat, 2, density)
  plot(x=NA, 
       xlim = range(sapply(dens_x, "[", "x")), 
       ylim = range(sapply(dens_x, "[", "y")), 
       ylab = "Probability")
  mapply(lines, dens_x, col=1:length(dens_x))
  title(main = "Density Plot for Each Regressor")
  legend("topright", legend=names(dens_x), fill=1:length(dens_x))
}

##########################################################################################