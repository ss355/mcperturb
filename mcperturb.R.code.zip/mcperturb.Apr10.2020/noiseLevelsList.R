##########################################################################################
######################### noiseLevelsList: Definition 
##########################################################################################
# This function adds random noise any variable in the xmatrix at multiple noise steps
# Puts these different noise levels x matricies in a list
# Then repeats multiple iterations
# Returns a list noise steps with a list of noisexmatrices  

# Mar 23, 2020 Monday SS note: I changed "noise.steps" to "noiseLevels".
noiseLevelsList = function(x.mat = x, noiseLevels = noisesteps, special.Vars = special.Vars, itera = iter)
{
   noiseMats = list() # Initializing a list of all noise Levels
   listAllNoiseLevels = list()
   # Initializing a list
   listAllNoiseLevelsNames = list()
  
   # Loop of different noise levels
   for(j in 1:length(noiseLevels))  
   { # Call of Function createNoiseLevs; List of all matricies at different noise Levels
     #listAllNoiseLevels[[j]] = createNoiseMat(x.mat, special.Vars,itera, noiseLevels,j)
    
     for(i in 1:itera)
     {
        noiseMats[[i]] = randomNoiseMat(x.mat, special.Vars, noiseLevels[j])
     }
     listAllNoiseLevels[[j]] = noiseMats
     listAllNoiseLevelsNames[j]  = c(paste(c(noiseLevels[j]*100), "%*sd"))
   }
  
  # Returns a list of different noise levels, with multiple iterations 
  return(structure(listAllNoiseLevels, names = listAllNoiseLevelsNames))
}

##########################################################################################