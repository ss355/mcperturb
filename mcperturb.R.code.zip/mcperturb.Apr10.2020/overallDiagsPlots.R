# ##########################################################################################
# Function Name:
# overallDiagsPlots
# 
# Function Descritption:
# Takes an X-matrix of numeric regressors and a numeric response variable, performs pertubation 
# analysis multiple (iter) times for each noiselevel. Calculates the lm summary statistics,
# and the overall multicollinearity diagnostic measures. Boxplots the disributions for the 
# selected diagnostic measure.  
#
# Function Usage:
# overallDiagsPlots = function(xmat = x, yvar = y, noiseLevels = NL.2,  spec.Vars = special.Vars,
#                   iter = iteration, choice = c(), mainLev=length(NL.2) )
# 
# Function Arguments:
# xmat          a numeric matrix or dataframe
# yvar          a numeric vector
# spec.Vars     a vector of noise variable name(s) or a matrix column identifier
# noiseLevels   a numaric vector or list
# iter          an interger
# choice        a character vector with the name of the overall diagnostic
# 
# Function Details:
# The overallDiagsPlots function provides an oppertunity to look at the how a overall diagnostic
# changes as the noise levels change per noise variable. The output boxplot is written to a pdf file. 
# In your working directory. 
# 
# Function Value:
# This function provides the opertunity for the user to observe the change in the distributions for each 
# diagnostic as a funciton of the noise variable and the noise level.
# 
# Function Note:
# This function is made to display the distributions of an overall diagnostic as the noise level and special variable 
# changes. The comparison to the original measurement should be observed. 
# This function is dependent on the cran "mctest" package.
# This function calls on the overallDiagsDiffs function to calculate the difference statistics for plotting, 
# the mctest::omcdiag function to calculate the overall multicollineatiy diagnost measures,
#
# Function Author(s)
# Ryan Zamora, Dr. Shuying Sun
# 
# Function Regerences:
# 
# Function See Also: (other functions)
# 
# Examples:
# 
# # Body dimensions data
# data(body_Dim)
# # X-matrix
# x = body_Dim[,c(10, 11, 16, 17, 21, 22, 24)]
# colnames(x) = c("shoulder", "chest", "bicep", "forearm", "wrist", "age", "height")
# special.Vars = c("shoulder")
## Making the noiselevels
# noiseStart = 0.05
# noiseEnd = 0.25
# noiseSteps = 0.05
# noiseLevs = seq(noiseStart, noiseEnd, by = noiseSteps)
# iteration = 50
# overallDiagsPlots(xmat = x, yvar = y, noiseLevels = NL.2, spec.Vars = special.Vars, iter = iteration, choice = c("d"), mainLev=length(NL.2))
# 
# #########################################################################################

# Mar 26, 2020 Thursday SS note: a new argument "mainLev" is added to "overallDiagsPlots" 
# as this argument was added to "overallDiagsDiffs". Set different values for "mainLev" 
# will not affect the boxplots generated from "overallDiagsPlots". This is because, 
# the boxplots are generated based on "overallDiagsDiffs" output [[k]] with k=2, 3, 
# ..., 7. But "overallDiagsDiffs" output[[1]] will be affected by the setting of "mainLev", 
# so it will affect "overallDigasRank" which calls "overallDiagsDiffs" ouput[[1]].

# Function Definition
overallDiagsPlots = function(xmat = x, yvar = y, noiseLevels = NL.2, spec.Vars = special.Vars, iter = iteration, choice = c(), mainLev=length(NL.2))
{
  cat("In overallDiagsPlots,--------------------------------------------------\n")
  cat("when calling overallDiagsDiffs, the main noise level mainLel that is used to \n") 
  cat("compare with the original data (with no noise added) is", mainLev, "\n")
  cat("---------------------------------------------------------------------\n")
 
  overdiag  = overallDiagsDiffs(xmat, yvar, spec.Vars, noiseLevels, iter, mainLev)
  over = omcdiag(xmat, yvar)$odiags
  choiceDiag = choice
  
  cat("--------------------------------------------------------------  \n")
  cat("In overallDiagsPlots, the choice argument can be: d, ch, r, s, t, co \n")
  cat("These choices corresponds to the 6 overal diagnostic measures.    \n")
  cat("                                                                  \n")
  cat("----- d is for the determinant of |X'X|  \n")
  cat("----- ch is for the Farr's Chi Sqaured statistics \n")
  cat("----- r is for the Red's indicator \n")
  cat("----- s is for the inverse sum of eigenvalues \n")
  cat("----- t is for the Theil's indicator \n")
  cat("----- co is for the condition number  \n")
  cat("--------------------------------------------------------------  \n")
  
  if(choiceDiag == "d")
  {
    
    boxplot(overdiag[[2]], ylim = c(min(overdiag[[2]], over[1]), max(overdiag[[2]],over[1])),
            main = paste("|X'X|, mainLev & noise variable:", mainLev,"&", spec.Vars),
            xlab = "Noise Levels", ylab = "Determinant")
    abline(h = over[1], lwd=4)  
  }
  else if(choiceDiag == "ch")
  {
    boxplot(overdiag[[3]], ylim = c(min(overdiag[[3]], over[2]), max(overdiag[[3]],over[2])), 
            main = paste("Chi Sqaured, mainLev & noise variable:", mainLev,"&", spec.Vars), 
            xlab = "Noise Levels", ylab = "Chi-Squred value")
    abline(h = over[2], lwd=4)  
  }
  else if(choiceDiag == "r")
  {
    boxplot(overdiag[[4]], ylim = c(min(overdiag[[4]], over[3]), max(overdiag[[4]],over[3])),
            main = paste("Red's indicator. mainLev & noise variable:", mainLev,"&", spec.Vars),
            xlab = "Noise Levels", ylab = "Red's Indicator")
    abline(h = over[3], lwd=4)
    
  }
  else if(choiceDiag == "s")
  {
    boxplot(overdiag[[5]], ylim = c(min(overdiag[[5]], over[4]), max(overdiag[[5]],over[4])),
            main = paste("Inverse sum. mainLev & noise variable:", mainLev,"&", spec.Vars),
            xlab = "Noise Levels", ylab = "inverse sum of eigenvalues")
    abline(h = over[4], lwd=4)
  }
  else if(choiceDiag == "t")
  {
    boxplot(overdiag[[6]], ylim = c(min(overdiag[[6]], over[5]), max(overdiag[[6]],over[5])),
            main = paste("Theil's indicator. mainLev & noise variable:", mainLev,"&", spec.Vars),
            xlab = "Noise Levels", ylab = "Theil's Indicator")
    abline(h = over[5], lwd=4)
  }
  else if(choiceDiag == "co")
  {
    boxplot(overdiag[[7]], ylim = c(min(overdiag[[7]], over[6]), max(overdiag[[7]],over[6])),
            main = paste("Condition number. mainLev & noise variable:", mainLev,"&", spec.Vars),
            xlab = "Noise Levels", ylab = "Condition number")
    abline(h = over[6], lwd=4) 
  }
}

#########################################################################################