# ##########################################################################################
# Function Name:
# overallDiagsRank
# 
# Function Descritption:
# Takes an X-matrix of numeric regressors and a numeric response variable, performs pertubation 
# analysis multiple (iter) times for each noiselevel. Calculates the overall multicollinearity 
# diagnostic measures. Calculates the difference between the original ovaerall diagnostic 
# and the mean change in diagnostic. Then ranks the influence that each variable has on the 
# overall diagnostic. It sums the overall ranks then ranks them. 1 = the most influential.
#
# Function Usage:
# overallDiagsRank = function(xmat = x, resp = y, noiseL = NL.1, itera = iteration, mainLev=length(NL.1))
# 
# Function Arguments:
# xmat          a numeric matrix or dataframe
# resp          a numeric vector
# noiseL        a numaric vector or list
# itera         an interger
# 
# Function Details:
# The overallDiagsRank function provides an oppertunity to look at the how the each variable 
# affects the overall diagnostic individually and ranks the magnitude of the difference. 
# Then sums up the ranking for a final rank of overall influce to a multicollinearity problem
# 
# Function Value:
# This function provides the opertunity for the user to observe how each variable influences the 
# overall diagnostics as noise is added to each variable. Ranking the difference between the original
# and the relative values can help rank the influence each regressor has with respect to multicollinearity
# 
# Function Note:
# This function is made to calculate and organize multiple multicollinearity diagnostics and seperated
# them by diagnostic. 
# This function is dependent on the cran "mctest" package.
# This function calls on the overallDiagsDiffs function to calculate the difference statistics, 
#
# Function Author(s)
# Ryan Zamora, Dr. Shuying Sun
# 
# Function Regerences:
# 
# Function See Also: (other functions)
# 
# Examples:
# 
# # Body dimensions data
# data(body_Dim)
# # X-matrix
# x = body_Dim[,c(10, 11, 16, 17, 21, 22, 24)]
# colnames(x) = c("shoulder", "chest", "bicep", "forearm", "wrist", "age", "height")
# special.Vars = c("shoulder")
## Making the noiselevels
# noiseStart = 0.05
# noiseEnd = 0.25
# noiseSteps = 0.05
# noiseLevs = seq(noiseStart, noiseEnd, by = noiseSteps)
# iteration = 5
# overallDiagsRank(xmat = x, resp = y, noiseL = noiseLevs, itera = iteration, mainLev=length(NL.1))
# 
# #########################################################################################


# Function Definition
overallDiagsRank = function(xmat = x, resp = y, noiseL = NL.1, itera = iteration, mainLev=length(NL.1))
{
  # Mar 26, 2020 Thursday SS notes
  # 1. A new argument "mainLev" is added to show at which noise level, 
  #     the resutls are compared with the original one. 
  # 2. In the following matrix, ncol= 7: col 1 is for "variable name", 
  #   col 2-7 are for 6 overall diagnostic measures, which are
  #   ("det", "chisquare", "red", "sumOfLambd", "theil", "condi")
  # 3. This functions calls "overallDiagsDiffs", but it only takes the 1st 
  #    in the output list, i.e., [[1]]. Another function "overallDiagsPlots"
  #    will use [[2]], [[3]], [[4]], [[5]], [[6]], [[7]]  
  
  cat("In overallDiagsRank,--------------------------------------------------\n")
  cat("when calling overallDiagsDiffs, the main noise level mainLel that is used to \n") 
  cat("compare with the original data (with no noise added) is", mainLev, "\n")
  cat("---------------------------------------------------------------------\n")
  
  diffMat = matrix(NA, nrow = dim(xmat)[2], ncol = 7)
  rankDiffMat = matrix(NA, nrow = dim(xmat)[2], ncol = 7)
  formatDiffMat = matrix(NA, nrow = dim(xmat)[2], ncol = 7)

  for(i in 1:dim(xmat)[2])
  {
    special.Vars = colnames(xmat)[i]
    diffMat[i,1] = special.Vars 
    # diffMat[i,2:7] = overallDiagsDiffs(xmat, resp, special.Vars, noiseL, itera)[[1]]
    diffMat[i,2:7] = overallDiagsDiffs(xmat, resp, special.Vars, noiseL, itera, mainLev)[[1]]
  }
  
  formatDiffMat[,1] = diffMat[,1]
  formatDiffMat[,2:dim(xmat)[2]] = formatC(diffMat[,2:dim(xmat)[2]],format = "e", digits = 3)
  absolutValDiff = abs(apply(diffMat[,2:7], 2, function(x)(as.numeric(x))))
  absMat = apply(absolutValDiff,2,function(x)(rank(-x)))
  sumMat = apply(absMat, 1, function(x)(sum(x)))
  overallRank = rank(sumMat)
  rankDiffMat = cbind(diffMat[,1],absMat,sumMat, overallRank)
  
  colnames(diffMat) = c("NoiseVariable", "detDiff", "chiSqrDiff", "redIndDiff", 
                        "sumOfLamDiff", "theilIndDiff", "conditionDiff")
  colnames(formatDiffMat) = colnames(diffMat)
  colnames(rankDiffMat) = c(colnames(diffMat), "Rank.Sum", "Overall.Rank")
  
  return(rankDiffMat)
}

#########################################################################################


