################################################################################
######################### Function: Boxplot individual variable and diagnostic 
#########################           vs All percentages
################################################################################
# Mar 24, 2020 Tuesday SS notes
# 1. After perturbing a "special.Var" (e.g., "shoulder") at different noise levels, check 
#    the 10 different diagnostic measures for each available regressor including the 
#    special.Var = "shoulder". For each regressor, 10 figures (for 10 diagnoistic measures)
#    are ploted. Each figure show the boxplots of different noise levels. 
# 2. In the 1st version "boxplotAllPerc.v1", for each regressor, a folder is generated.
#    with each folder, there are 10 figurs. In this current version, thre are only 
#    ONE pdf figure is geneated, in each pdf, there are 10 figures on two pages. 
#    For the code lines that are removed, see the end of this code file.
# 3. The default setting for the pdf file with 10 figures are set up as 
#     "width=8, height=11", and "par(mfrow=c(3,2))". These can be changed. 

boxplotAllPerc = function(xmatrix = x, y = y, noiseLevs = noiseLevs, special.Vars = special.Vars, iteration = iteration, path = NULL)
{
  summaryresults = diagout(xmatrix, y, noiseLevs, special.Vars, iteration)
  diagnames = names(summaryresults)
  var = list()
  diagMat = list()
  
  if(is.null(path)) 
  {
    path = getwd()
  }
  newDir = "boxplotAllPerc"
  if(file.exists(newDir))
  {
    setwd(file.path(path, newDir))
  }
  else
  {
    dir.create(file.path(path, newDir))
    setwd(file.path(path, newDir))
  }
  noiseDir = paste(special.Vars,"noise",sep = "_")
  if(file.exists(noiseDir))
  {
    setwd(file.path(path, newDir, noiseDir))
  }
  else
  {
    dir.create(file.path(path, newDir, noiseDir))
    setwd(file.path(path, newDir, noiseDir))
  }

  for(k in 1:dim(xmatrix)[2])
  {# Should go k = 7 variables 
  	
     pdf(paste(as.character(colnames(xmatrix)[k]), "All", special.Vars, "NoiseLevels", "pdf", sep = "."), onefile=T, width=8, height=11)
     par(mfrow=c(3,2))
    
    for(j in 1:length(summaryresults))
    {# Should go j = 10 diagnostic loops
      for(i in 1:length(noiseLevs))
      {# should go through a sequence of noise levels 10  
        var[[i]] = summaryresults[[j]][[i]][k]
      }
      diagMat[[j]] = var
      # pdf(paste(as.character(colnames(xmatrix)[k]), diagnames[[j]],"All", special.Vars, "NoiseLevels", "pdf", sep = "."), onefile=T)
      # par(cex.lab=1.5,cex.axis=1.5)
      boxplot(as.data.frame(diagMat[[j]]), main = paste(paste(colnames(xmatrix)[k]),"'s", paste(diagnames[[j]]), ", noise variabe:", paste(special.Vars)), xlab = paste("Noise Levels %"), ylab = paste(as.character(colnames(xmatrix)[k]),diagnames[[j]]),  names = noiseLevs)
      # dev.off()
    }
    dev.off()
    setwd(file.path(path, newDir, noiseDir))
  }
  setwd(file.path(path))
  outputPath = paste("Figures in the boxplotAllPerc folder under", paste(getwd()), "directory") 
  print(outputPath)

}

#############################################################################
# For each variable, one PDF file (with 10 figures on 2 pages ) instead of 10 pdf 
# figures are generated. After "for(k in 1:dim(xmatrix)[2])", the following are removed. 
# for(k in 1:dim(xmatrix)[2])
# {# Should go k = 7 variables 
    # vpath = getwd()
    # varDir = names(xmatrix[k])
    # if(file.exists(varDir))
    # {
    #   setwd(file.path(vpath, varDir))
    # }
    # else
    # {
    #    dir.create(file.path(vpath, varDir))
    #    setwd(file.path(vpath, varDir))
    # }
    