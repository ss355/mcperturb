# ##########################################################################################
# Function Name:
# rateOfChange
# 
# Function Descritption:
# Takes an X-matrix of numeric regressors and a numeric response variable, performs perturbation 
# analysis multiple (iter) times for each noiselevel. Calculates the rate of change and least square
# best fit line for all the individual/overall multicollinearity diagnostic measures
# The function returns an object with a list of the minimum mean, maximum mean, rate of change
# and least squares betst fit sllope value for each diagnostic with respect to the noise added 
# to each variable. 
#
# Function Usage:
# rateOfChange = function(xmat = x, y = y, noiseLevs = noiseLevs, special.Vars = special.Vars, iteration = iteration)
# 
# Function Arguments:
# xmat             a numeric matrix or dataframe
# y             a numeric vector
# noiseLevs     a numaric vector or list
# special.Vars  a vector of noise variable name(s) or a matrix column identifier
# iteration     an interger
# 
# Function Details:
# The rateOfChange function provides an oppertunity to look at the rate each multicollineatity 
# diagnostic measure changes with respect to the noise added to a regressor. 
# 
# Function Value:
# This function provides the opportunity for the user observe the rate at which each 
# regressor's indivudual diagnostic measures change as more noise is added to a noise 
# varible. The variable whose rate of change values is large is the variable that 
# have a coupling relationship with the noise regressor
# 
# Function Note:
# This function is made to calculate and organize the minimum and maximum and 
# rate of change, leastsquares best fit values.
# This function is dependent on the cran "mctest" package.
# This function calls on the diagout function to calculate the pertub analysis, 
# and the mctest::imcdiag function to calculate the individual diagnoistic mesures.
#
# Function Author(s)
# Ryan Zamora, Dr. Shuying Sun
# 
# Function Regerences:
# 
# Function See Also: (other functions)
# 
# Examples:
# 
# # Body dimensions data
# data(body_Dim)
# # X-matrix
# x = body_Dim[,c(10, 11, 16, 17, 21, 22, 24)]
# colnames(x) = c("shoulder", "chest", "bicep", "forearm", "wrist", "age", "height")
# special.Vars = c("shoulder")
# # Making the noiselevels
# noiseStart = 0.025
# noiseEnd = 0.25
# noiseSteps = 0.025
# noiseLevs = seq(noiseStart, noiseEnd, by = noiseSteps)
# iteration = 5
# rateOfChange(xmat = x, y = y, noiseLevs = noiseLevs, special.Vars = special.Vars, iteration = iteration)
# 
# #########################################################################################

rateOfChange = function(xmat = x, y = y, noiseLevs = noiseLevs, special.Vars = special.Vars, iteration = iteration)
{
  summaryresultsList = diagout(xmat, y, noiseLevs, special.Vars, iteration)
  origdiagMat = cbind(summary(lm(y~ ., data = xmat))$coefficients[2:(dim(xmat)[2]+1),1:3], imcdiag(xmat,y)$idiags[,1:7])
  noisechange = max(noiseLevs) * sd(xmat[,special.Vars])
  newNoiseLevs = c(0,noiseLevs) * sd(xmat[,special.Vars])
  medianMat = matrix(data = NA, nrow = length(summaryresultsList), ncol = length(noiseLevs)) 
  medianList = list()
  
  for(k in 1:dim(xmat)[2])
  {# Should go k = 7 variables 
    for(j in 1:length(summaryresultsList))
    {# Should go j = 10 diagnostic loops
      for(i in 1:length(noiseLevs))
      {# should go through a sequence of noise levels 10  
        medianMat[j,i] = median(as.matrix(summaryresultsList[[j]][[i]][k]))
      }
    }
    medianList[[k]] = cbind(origdiagMat[k,], medianMat)
    medianMat = matrix(data = NA, nrow = length(summaryresultsList), ncol = length(noiseLevs)) 
  }
  
  d = matrix(data = NA, nrow = length(summaryresultsList), ncol = dim(xmat)[2])
  z = matrix(data = NA, nrow = length(summaryresultsList), ncol = dim(xmat)[2])
  lmMat = matrix(data = NA, nrow = length(summaryresultsList), ncol = dim(xmat)[2])
  summaryMat = matrix(data = NA, nrow = dim(xmat)[2], ncol = 4)
  tableList = list()
  
  for(j in 1:length(summaryresultsList))
  {#ix(data = NA, nrow = length(summaryresultsList), ncol = length(noiseLevs)) 
    for(k in 1:dim(xmat)[2])
    {
       d[j,k] = max(medianList[[k]][j,])
       z[j,k] = min(medianList[[k]][j,])
       lmMat[j,k] = lm(medianList[[k]][j,]~newNoiseLevs)$coefficients[2]
    }
    maxMat = round(d, 3)
    minMat = round(z, 3)
    diffMat = round(d - z, 3) 
    summaryMat[,1] = origdiagMat[,j]
    summaryMat[,2] = diffMat[j,]
    summaryMat[,3] = lmMat[j,]
    # summaryMat[,4] = diffMat[j,] / -noisechange
    summaryMat[,4] = diffMat[j,]/(-noisechange)
    diagdf = as.data.frame(round(summaryMat, 3)) 
    rownames(diagdf) = colnames(xmat) 
    #colnames(diagdf) = c("Original-Values", "Max-Median", "Min-Median", "Diff-Median", "Least-squares-fit", "Rate-of-Change")
    colnames(diagdf) = c("Original-Values", "Diff-Median", "Least-squares-fit", "Rate-of-Change")
    tableList[[j]] = diagdf
  }
  
  diagna = c("Coeff.Table", "StdError.Table", "t-stats.Table", "VIF.Table", "TOL.Table", 
                "Wi.Table", "Fi.Table", "Leamer.Table", "CVIF.Table", "Klein.Table")
  return(structure(tableList, names = diagna))
}

#########################################################################################
