# ##########################################################################################
# Function Name:
# rsqdPlots
# 
# Function Descritption:
# Takes an X-matrix of numeric regressors and a numeric response variable, ranks the
# regressors by their pearson correlations with the response. Calculates the regression
# models by adding one regressor at a time. Starting with the highest in magnitude
# correlated regressor to lowest. Returns a plot of r-squared or adjusted r-squared values
# for all regression models.
# 
# Function Usage:
# rsqdPlots(xmat, response, adjrsq = FALSE)
# 
# Function Arguments:
# xmat        a numeric matrix
# response    a numeric vector
# adjrsq      lofical. If TRUE the adjusted r-squared values will be calculated and plotted
# 
# Function Details:
# The rsqdPlots function provides an oppertunity to observe the the regressors that are not
# providing any new information to the overall models R-squared or R-squared adjusted values.
# 
# Function Value:
# This function provides the opertunity for the user to observe a plots of  model statistics
# for easy identification of insignificant variables. This observational analysis helps
# identify variables that might be proviing redundant information and is usefull for
# identifying a multicollinearity problem.
# 
# Function Note:
# This function is made to sequentially perform Regression models by including each variable
# one at a time. The oder of the variables is based on their correlation with the response.
# In order for this function to work, the length of each column vector must be the same.
# Therefore, if there exist a missing value, then the whole observation must be removed.
# If the of observations must be kept, then an imputation of must occur.
# 
# Function Author(s)
# Ryan Zamora, Dr. Shuying Sun
# 
# Function Regerences:
# 
# Function See Also: (other functions)
# 
# Examples:
# 
# # Body dimensions data
# data(body_Dim)
# # X-matrix
# x = body_Dim[,c(10, 11, 16, 17, 21, 22, 24)]
# colnames(x) = c("shoulder", "chest", "bicep", "forearm", "wrist", "age", "height")
# rsqdPlots(x,y)
# rsqdPlots(x,y,TRUE)
# 
# #########################################################################################

rsqdPlots = function(xmat = x, response = y, adjrsq = FALSE)
{
  corMat = rank(-apply(xmat, 2, function(x){cor(x,response)}))
  new_xmat = xmat[,corMat]
  
  if(adjrsq==TRUE)
  {
    adjrsqd = summary(lm(response~new_xmat[,1]))$adj.r.squared
    for(i in 2:dim(xmat)[2])
    {
      adjrsqd = c(adjrsqd, summary(lm(response~.,data=new_xmat[,1:i]))$adj.r.squared)
    }
    plot(adjrsqd,type="b",main = "Regression models adjusted R-squared values",
         xlab = "Newest variable included", ylab = "Adjusted R-Squared Value",xaxt = "n")
    axis(1, at = 1:dim(xmat)[2], labels = colnames(new_xmat))
  }
  else
  {
    rsqd = summary(lm(response~new_xmat[,1]))$r.squared
    for(i in 2:dim(xmat)[2])
    {
      rsqd = c(rsqd, summary(lm(response~.,data=new_xmat[,1:i]))$r.squared)
    }
    plot(rsqd,type="b",main = "Regression models R-squared values",
         xlab = "Newest variable included", ylab = "R-Squared Value",xaxt = "n")
    axis(1, at = 1:dim(xmat)[2], labels = colnames(new_xmat))
  }
}
#########################################################################################