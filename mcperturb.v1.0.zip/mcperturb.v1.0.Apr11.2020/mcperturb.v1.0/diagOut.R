################################################################################
######################### Function: diagout definition 
################################################################################
# 1. This function organize all the diagnostics into a list of list 
# 2. It calls the "noiseLevelsList" (which calls "randomNoiseMat") and 
#    "imcdiag" (of the mctest package to calculate indiviudal measures)
# 3. It loops through each noise level "j in 1:length(noiseLevels)", and 
#    for each noise level, it loops through each iteration "i in 1:iter". 
# 4. The output is a list of lists. This list with a lengh of 10 for 
#    10 different diagnostic measures with the following names:
#    "coeffList", "stderrorList", "tstatsList", "vifList", "tolList", 
#     "wiList", "fiList", "leamerList", "cvifList", "kleinList". 
#    The first 3 are basic lm output (cofficient, standard_error, t_statis
#     of the β_hat).The next 7 are the 7 multicolinearity diagnoistic 
#     measures: vif, tol, wi, fi, leamer, cv, flein. See the end of this code 
#     for an example of the output.  

# The above notes are added by SS on Mar 23 and 24, 2020. 
# An additional note: I changed "noisesteps" (NOT noiseSteps) to noiseLevels
# to be reflect the correct meaning and be consistent with other functions. 

diagout = function(xmat = x, response = y, noiseLevels = seq(noiseStart, noiseEnd, by = noiseSteps), special.Var = c("shoulder"), iter = iteration)
{
  ndiagcol  = dim(xmat)[2]
  
  # Model statistics
  coeffMat = matrix(nrow =  iter, ncol = ndiagcol)
  stderrorMat = matrix(nrow =  iter, ncol = ndiagcol)
  tstatsMat = matrix(nrow =  iter, ncol = ndiagcol)
  
  # Diagnostic measures
  vifMat = matrix(nrow =  iter, ncol = ndiagcol)
  tolMat = matrix(nrow =  iter, ncol = ndiagcol)
  wiMat = matrix(nrow =  iter, ncol = ndiagcol)
  fiMat = matrix(nrow =  iter, ncol = ndiagcol)
  leamerMat = matrix(nrow =  iter, ncol = ndiagcol)
  cvifMat = matrix(nrow =  iter, ncol = ndiagcol)
  kleinMat = matrix(nrow =  iter, ncol = ndiagcol)
  
  # Initializing the List 
  # Model statistics
  coeffList = list()
  stderrorList = list()
  tstatsList = list()
  
  # Diagnostic measures
  vifList = list()
  tolList = list()
  wiList = list()
  fiList = list()
  leamerList = list()
  cvifList = list()
  kleinList = list()
  
  # Calling noiselevs function 
  noiseresults = noiseLevelsList(xmat, noiseLevels, special.Var, iter)
  
  # Loop through the list of noiseLevels
  for(j in 1:length(noiseLevels)) 
  {
    # Loop through the iterations 
    for(i in 1:iter)  
    {
      # Calculating the linear model 
      regmodel = lm(response ~., data = as.data.frame(noiseresults[[j]][i]))
      
      # Filling in the model statistics 
      coeffMat[i,] = t(regmodel$coefficients[2:(ndiagcol+1)])
      stderrorMat[i,] = t((summary(regmodel))$coefficients[2:(ndiagcol+1),2])
      tstatsMat[i,] = t((summary(regmodel))$coefficients[2:(ndiagcol+1),3])
      
      # Calculating  the Individual diagnostics measures
      diagnostics = imcdiag(as.data.frame(noiseresults[[j]][i]), response)    
      
      # Filling in the diagnostic matrices
      vifMat[i,] = t(diagnostics$idiags[,1])
      tolMat[i,] = t(diagnostics$idiags[,2])
      wiMat[i,] = t(diagnostics$idiags[,3])
      fiMat[i,] = t(diagnostics$idiags[,4])
      leamerMat[i,] = t(diagnostics$idiags[,5])
      cvifMat[i,] = t(diagnostics$idiags[,6])
      kleinMat[i,] = t(diagnostics$idiags[,7])
    }
    # Filling in the List of model stats at different noise levels  
    coeffList[[j]] = as.data.frame(coeffMat)
    stderrorList[[j]] = as.data.frame(stderrorMat)
    tstatsList[[j]] = as.data.frame(tstatsMat)
    
    # Filling in the List of diagnostic measures at different noise levels.   
    vifList[[j]] = as.data.frame(vifMat)
    tolList[[j]] = as.data.frame(tolMat)
    wiList[[j]] = as.data.frame(wiMat)
    fiList[[j]] = as.data.frame(fiMat)
    leamerList[[j]] = as.data.frame(leamerMat)
    cvifList[[j]] = as.data.frame(cvifMat)
    kleinList[[j]] = as.data.frame(kleinMat)
  }
  # Making a list of all diagnostic measures 
  diagList = list(coeffList, stderrorList, tstatsList, vifList, tolList, 
                  wiList, fiList, leamerList, cvifList, kleinList)
  
  diagnames = c("coeffList", "stderrorList", "tstatsList", "vifList", "tolList", 
                "wiList", "fiList", "leamerList", "cvifList", "kleinList")
  
  return(structure(diagList, names = diagnames))
}

################################################################################

# set.seed(6677)
## Body dimensions data
##  X-matrix
# x = body_dat[,c(10, 11, 16, 17, 21, 22, 24)]
# colnames(x) = c("shoulder", "chest", "bicep", "forearm", "wrist", "age", "height")
##  Response Variable 
# y = body_dat[,23]
## Noise Variable
# special.Var = "shoulder"
## Making the noiselevels
# noiseStart = 0.1
# noiseEnd = 0.4
# noiseSteps = 0.2
# noiseLevs = seq(noiseStart, noiseEnd, by = noiseSteps)
## > noiseLevs  # [1] 0.1 0.3
# diagout.output.3iter<-diagout(xmat = x, response = y,  noiseLevels = noiseLevs, special.Var= special.Var, iter = 3) 
# diagout.output.3iter

## Mar 24, 2020 Summary notes of "dignout" output: 
## A list of list 10, for 10 different diagnoistsics. 
## > diagout.output.3iter[[4]][[2]] # means I want to get the 4th diagnoistic measure (VIF) and the 2nd noise level (0.3) 
##        V1       V2       V3       V4       V5       V6       V7
## 1 5.408821 7.894485 11.94366 14.78930 6.260021 1.127068 2.096182
## 2 5.262340 8.326743 11.89284 14.62762 6.277886 1.125659 2.109309
## 3 5.576560 8.390851 12.00558 14.59277 6.302922 1.126524 2.050332

## "diagout.output.3iter[[4]][[2]][3]" means I want to get the 4th diagnoistic measure (VIF) 
##  at the 2nd noise level (0.3) and the 3rd variable/regressor.
##  So the "diagout" output summaryResults[[j]][[i]][k] means
##  the "j_th" diagnoistic measure, the i_th noise level, and the k_th variable/regressor.  
 
## > diagout.output.3iter[[4]][[2]][3]
##        V3
## 1   11.94366
## 2   11.89284
## 3   12.00558
