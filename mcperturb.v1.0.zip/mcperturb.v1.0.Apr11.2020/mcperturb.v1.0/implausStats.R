# #########################################################################################
# Function Name: implausStats
# 
# Function Descritption:
# Takes in a matrix of variables, correlates each variable with the response,
# peforms a simple linear regression (SLR) model with each variable,
# performs a multiple linear regression model (MLR) using all of the variables
# Outputs a summary table of correlations, SLR statistics, and MLR statistics
# 
# Function Usage:
# implausStats(xmat, response)
# 
# Function Arguments:
# xmat          A nummeric design matrix with the equal row lengths
# response      A numeric vector
# 
# Function Details:
# The implausStats function provides an oppertunity to observe the implausible SLR and
# MLR coefficients and standard errors for each regressor. The function allows a Comparison
# between the SLR Coefficients and the correlations each variable has with the regressor.
# 
# Function Value:
# This function provides the opertunity for the user to observe model statistics for easy
# comparisons. This observational analysis helps identify inconsistancies that might be
# usefull for identifying a multicollinearity problem.
# 
# Function Note:
# This function is made to calculate correlations and SLR and MLR model statistics.
# In order for this function to work, the length of each column vector must be the same.
# Therefore, if there exist a missing value, then the whole observation must be removed.
# If the of observations must be kept, then an imputation of must occur.
# 
# Function Author(s)
# Ryan Zamora, Dr. Shuying Sun
# 
# Function References:
# 
# Function See Also: (other functions)
# 
# Examples:
# 
# # Body dimensions data
# data(body_Dim)
# # X-matrix
# x = body_Dim[,c(10, 11, 16, 17, 21, 22, 24)]
# implausStats(xmat = x, response = y)
# 
# 
# ##########################################################################################

implausStats = function(xmat = x, response = y)
{
  indCorr = apply(xmat,2,function(x)(cor(x,response)))
  indivStats = apply(xmat,2,function(x)(summary(lm(response~x))))
  indivCoeffs = lapply(indivStats,function(x)(coef(x)[2]))
  indivStd.errs = lapply(indivStats,function(x)(coefficients(x)[2,2]))
  allVarsStats = summary(lm(response~.,data=xmat))$coefficients  
  estimates = allVarsStats[2:(dim(xmat)+1)[2],1]
  std.errors = allVarsStats[2:(dim(xmat)+1)[2],2]
  summaryTable = cbind(indCorr, indivCoeffs, estimates, indivStd.errs, std.errors)
  colnames(summaryTable) = c("Corr.w.Resp", "SLR.Coeff", "MLR.Coeff", "SLR.Std.err", "MLR.Std.err" ) 
  return(summaryTable)
}

##########################################################################################
