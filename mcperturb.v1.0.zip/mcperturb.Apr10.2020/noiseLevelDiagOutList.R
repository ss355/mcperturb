# ##########################################################################################
# Function Name:
# noiseLevelDiagOutList
# 
# Function Descritption:
# Takes an X-matrix of numeric regressors and a numeric response variable, performs pertubation 
# analysis multiple (iter) times for each noiselevel. Calculates the lm summary statistics,
# and the individual/overall multicollinearity diagnostic measures
# The function returns an object with a list of the different diagnoistcs for n iterations 
# at every noise step and a name for every noise level. 
#
# Function Usage:
# noiseLevelDiagOutList = function(x, y, special.Var, noiseLevels, iter, col.num.of.special.Var)
# 
# Function Arguments:
# xmat          a numeric matrix or dataframe
# y             a numeric vector
# special.Var   a variable name, radom noise will be added to this variable
# noiseLevels   a numaric vector or list of several noise levels. 
# iter          an interger
# 
# Function Details:
# The noiseLevelDiagOutList function provides an oppertunity to look at the multicollineatity diagnostic 
# measures in a structured format. 
# 
# Function Value:
# This function provides the oppertunity for the user to have the raw calculations for the 
# lm summary statistics, individual diagnostic measures, and the overall diagnostic measures
# sturctered in a list format. 
# 
# Function Note:
# This function is made to calculate and organize multiple multicollinearity diagnostics and seperated
# them by the amount of noise used to perturb each variable for multiple iterations. 
# This function is dependent on the cran "mctest" package.
# This function calls on the regModeStats function to calculate the regression model statistics, 
# the mctest::omcdiag function to calculate the overall multicollineatiy diagnost measures,
# and the mctest::imcdiag function to calculate the individual diagnoistic mesures.
#
# Function Author(s)
# Ryan Zamora, Dr. Shuying Sun
# 
# Function Regerences:
# 
# Function See Also: (other functions)
# 
# Examples:
# 
# set.seed(6677)
# # Body dimensions data
# data(body_Dim)
# # X-matrix
# x = body_Dim[,c(10, 11, 16, 17, 21, 22, 24)]
# colnames(x) = c("shoulder", "chest", "bicep", "forearm", "wrist", "age", "height")
# special.Vars = c("shoulder")
## Making the noiselevels
# noiseStart = 0.05
# noiseEnd = 0.25
# noiseSteps = 0.05
# noiseLevs = seq(noiseStart, noiseEnd, by = noiseSteps)
# iteration = 5
# noiseLevelDiagOutList(xmat = x, y = y, special.Var = special.Var, noiseLevels = noiseLevs, iter = iteration, col.num.of.special.Var=c(1))
# 
# #########################################################################################

# Function Definition
noiseLevelDiagOutList = function(xmat = x, y = c(), special.Var = c(), noiseLevels = c(), iter = c(1))
{
  diagOutList = list()
  
  # Calculates the original diagnostics 
  origDiagList = list(regModelStats(x, y), omcdiag(x, y)$odiags, imcdiag(x, y)$idiags)
  
  # Initializing a list of all noise Levels
  listAllNoiseLevels = list(origDiagList) 
  # Initializing a list
  listAllNoiseLevelsNames = list(c("Level 0"))
  
  # Loop of different noise levels
  for(j in 1:length(noiseLevels))  
  { 
    for(i in 1:iter)
    {
      ## diagOutList[[i]] = list(regModelStats(randomNoiseMat(x, special.Vars, noiseLevels), y),
      ##                         omcdiag(randomNoiseMat(x, special.Vars, noiseLevels), y)$odiags,
      ##                         imcdiag(randomNoiseMat(x, special.Vars, noiseLevels), y)$idiags)
      
      randomNoiseMat.j.i<-randomNoiseMat(x_mat =xmat, special_Var = special.Var, noiseLevel=noiseLevels[j])
      diagOutList[[i]] = list(regModelStats(randomNoiseMat.j.i, y),
                              omcdiag(randomNoiseMat.j.i, y)$odiags,
                              imcdiag(randomNoiseMat.j.i, y)$idiags)  
                           
    }
    listAllNoiseLevels[[(j+1)]] =  diagOutList
    listAllNoiseLevelsNames[(j+1)]  = c(paste("Level ",j, ":", noiseLevels[j],sep=""))
  }
  # Returns a list of different noise levels, with multiple iterations 
  return(structure(listAllNoiseLevels, names = listAllNoiseLevelsNames))
}

# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
## Mar 20, 2020 Debug notes by SS: The following code lines are not correct:
## 
##      diagOutList[[i]] = list(regModelStats(randomNoiseMat(x, special.Vars, noiseLevels), y),
##                              omcdiag(randomNoiseMat(x, special.Vars, noiseLevels), y)$odiags,
##                              imcdiag(randomNoiseMat(x, special.Vars, noiseLevels), y)$idiags)
##  They are not correct for the following reasons:
## (1) "noiseLevels" should be changed noiseLevel.j or "noiseLevels[j]"
## (2) "randomNoiseMat(x, special.Vars, noiseLevels)" should be run just one time, then 
##     save the result in a matrix to be used as an input for "omcdiag" and "imcdiag"

# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
## Mar 25, 2020 The following are some notes on the output of this function 

# We run a small iteration (iteration =1) and 2 noise levels (0.1, and 0.3) to show the results and avoid generating a large output
# The output is a list of lists. The length of the list is 3 for three 3 levels:
#  "Level 0", output based based on the raw/original data, i.e., no noise added;  
#  "Level 1", output based on a new data with at noise level 1= 0.1 noise added;
#  "Level 1", output based on a new data with at noise level 1= 0.3 noise added. 
#  At each level, there are three different outputs, they are 
#  linear regression (lm) summary, output of omcdiag (overall diagonsis), and of imcdiag (individual diagnosis)
# Note, the Level 0 (indexed as Level "1", with no noise) and Level 1 (indexed as Level 2, 
# with "0.1" noise) output are different. Level 0 is simple as it has no results of different
# "iterations", but for Level 1, 2, ..., it will have resutls of different iterations. 

# See "Additional output of 'noiseLevelDiagOutList'" in Mar19.2020.Scripts.for.R.Documentation.txt". 

# See the following notes and script from "OverallDiagOut". 

    # summaryList = noiseLevelDiagOutList(x,y,special.Vars, noiseLevs, iteration)
    
    ##  The output of "noiseLevelDiagOutList" is a "noiselevel + 1" list. 
    ##  The "1" is for the original data before adding noise. In the following code 
    ##  "summaryList[[1]][[2]][k= 1:6]", "[[1]]" means it is level 0, i.e., it is based on
    ##  the orignal data without any noise added to it. "[[2]]" is for "omcdiag" output 
    ##  with 6 overall diagnostic measures. However, for "j in 2:length(summaryList)", 
    ##  That is, for level ≥ 2 with "n-iteration" for each noise level, in 
    ##  "summaryList[[j]][[i]][[2]][1]", this "[[i]]' mean "iteration", and the [[2]]
    ##  is for "omcdiag" output with 6 overall diagnostic measures. 
    
    # origDet = summaryList[[1]][[2]][1]
    # origChiSqr = summaryList[[1]][[2]][2]
    # origRedInd = summaryList[[1]][[2]][3]
    # origSumofLam = summaryList[[1]][[2]][4]
    # origTheilInd = summaryList[[1]][[2]][5]
    # origCondNum = summaryList[[1]][[2]][6]
    
    # for(j in 2:length(summaryList))
    # {
    #   for(i in 1:iteration)
    #   {
    #     detMat[i,(j-1)] = summaryList[[j]][[i]][[2]][1]
    #     chiSqrMat[i,(j-1)] = summaryList[[j]][[i]][[2]][2]
    #     redIndMat[i,(j-1)] = summaryList[[j]][[i]][[2]][3]
    #     sumOfLamMat[i,(j-1)] = summaryList[[j]][[i]][[2]][4]
    #    theilIndMat[i,(j-1)] = summaryList[[j]][[i]][[2]][5]
    #    conditionMat[i,(j-1)] = summaryList[[j]][[i]][[2]][6]    
    #   }
    # }
    
# See below for the level 2 results. 
 
# $`Level 2`
# $`Level 2`[[1]]
# $`Level 2`[[1]][[1]]
#             Estimate Std. Error    t value
# shoulder  0.03428237 0.04783340  0.7167035
# chest     0.63574288 0.06361726  9.9932445
# bicep     0.48574489 0.17983104  2.7011182
# forearm   0.67731383 0.29932884  2.2627750
# wrist    -0.29011302 0.40097810 -0.7235134
# age       0.03385730 0.02444551  1.3850105
# height    0.33761750 0.03381569  9.9840479

# $`Level 2`[[1]][[2]]
#                            results detection
# Determinant           2.657659e-04         1
# Farrar Chi-Square     4.139774e+03         1
# Red Indicator         6.849702e-01         1
# sum of Lambda Invers  4.993366e+01         1
# Theil Indicator      -1.598519e-01         0
# Condition Number      1.203939e+02         1

# $`Level 2`[[1]][[3]]
#                VIF        TOL         Wi         Fi    Leamer        CVIF Klein
# shoulder  5.533139 0.18072925  377.76155  454.22049 0.4251226 -0.23359085     0
# chest     8.322549 0.12015550  610.21241  733.71940 0.3466345 -0.35135054     1
# bicep    11.928677 0.08383159  910.72312 1095.05347 0.2895369 -0.50358938     1
# forearm  14.681091 0.06811483 1140.09094 1370.84534 0.2609882 -0.61978721     1
# wrist     6.270406 0.15947931  439.20050  528.09468 0.3993486 -0.26471584     0
# age       1.128282 0.88630336   10.69015   12.85384 0.9414369 -0.04763234     0
# height    2.069514 0.48320523   89.12617  107.16531 0.6951296 -0.08736805     0
#                  IND1      IND2
# shoulder 0.0021687510 1.1428235
# chest    0.0014418660 1.2273195
# bicep    0.0010059791 1.2779888
# forearm  0.0008173779 1.2999125
# wrist    0.0019137517 1.1724657
# age      0.0106356403 0.1585986
# height   0.0057984627 0.7208914


