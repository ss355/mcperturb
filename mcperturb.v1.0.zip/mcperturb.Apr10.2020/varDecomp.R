####################################################################################################
# This function will give the user the chance to calculate variance decomposition proportions 
# based on the the functions provided by the mctest and/or perturb package

varDecomp = function(df = x, intercept = FALSE, na.rm = TRUE, scale = TRUE, center = TRUE, mct = TRUE, pert = TRUE)
{
  if(mct){
     e = eigprop(x = df, na.rm = na.rm, Inter = intercept)
  }
  else{e = NULL}
  
  if(pert){
     c = colldiag(mod = df, scale = scale, center = center, add.intercept = intercept)
  }
  else{c = NULL}
  
  varDecList = list(e,c)
  names(varDecList) = c("mctest_eigprop", "perturb_colldiag")
  return(varDecList)
}
