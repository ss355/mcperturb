# ##########################################################################################
# Function Name:
# randomNoiseMat
# 
# Function Descritption:
# Takes an X-matrix of numeric regressors and adds random noise to a variable selected 
# as a special variable. Adds random noise to this selected variable and returns
# a new x-matrix with noise added to this regressor. 
# 
# Function Usage:
# randomNoiseMat(xmat, special_Vars, noiseLevels)
# 
# Function Arguments:
# xmat          a numeric matrix or dataframe
# special_Vars  a vector identifying variable to add noise to
# noiseLevels   a numeric vector or list 
# 
# Function Details:
# The randomNoiseMat function is used as an intermediate function for the mcperturb package.
# 
# Function Value:
# This function is used to add random noise to the X-matrix systematically
# 
# Function Note:
# This function is used for the mcperturb package as a supporting function.
# This function returns a noise matrix with the same diminsions as the originial x-matrix.
# If no noise variables are selected then all of the variables will have random noise added to them. 
# This function will not run if it is not given an x-matrix
# This function does not call on any function
# 
# Function Author(s)
# Ryan Zamora, Dr. Shuying Sun
# 
# Function References:
# 
# Function See Also: (other functions)
# 
# Examples:
# 
# # Body dimensions data
# data(body_Dim)
# # X-matrix
# x = body_Dim[,c(10, 11, 16, 17, 21, 22, 24)]
# colnames(x) = c("shoulder", "chest", "bicep", "forearm", "wrist", "age", "height")
# special.Vars = c("shoulder")
# 
# randomNoiseMat(x_mat = x, special_Var = special.Var, noiseLevel = noiseLev =0.05)
# 
# # Mar 20, 2020 SS debug/change notes regarding "randomNoiseMat.R" 
# (1) I change it to add noise for only ONE variable, not a list of variables
# (2) I change it to add only one noise level, NOT a list of several noise levels. 
# #########################################################################################

# Function Definition
# randomNoiseMat = function(x_mat = c(), special_Vars = c(), noiseLevels = c())
randomNoiseMat = function(x_mat = x, special_Var = c(), noiseLevel = c())
{
  # Dummy matrix
  newxmatrix = x_mat
  
  # True if noise added to all variables
  # if(is.null(special_Vars))
  # { # Loop of all noise matrices
  #  noiseXmatrix = as.data.frame(apply(x_mat,2,function(v)(x+rnorm(dim(x_mat)[1],mean=0,sd=(noiseLevels*sd(v))))))
  # }
 
  if( length( special_Var) ==0 || length( special_Var) >1)
  { 
  	cat("------------------------------------------------------------------------, \n") 
  	cat("In the function randomNoiseMat, which is called by noiseLevelDiagOutList, \n") 
  	
  	if ( length( special_Var) ==0 ) 
  	{ 
       cat("length( special_Var) is 0, that is, you did not specify a variable \n")
    }
  	else 
  	{  
  		cat(" length( special_Var)  is > 1, i.e., you listed more than variable \n") 
    }
    stop("Because of the above reason, randomNoiseMat crashed, please check your input setting. ")
  }
  
  else
  { # Loop of selected variables noise matrices 
    for (var.col in special_Var)
    { # Fillling in the dummy matrix. Note, if there is only "one variable", no need to use a loop

      random.noise.vec<- rnorm(dim(x_mat)[1], mean=0, sd=(noiseLevel*sd(x_mat[, var.col])))
      newxmatrix[, var.col]= x_mat[, var.col]+ random.noise.vec
      # x_mat[, var.col] = x_mat[, var.col]+ random.noise.vec
      # newxmatrix[, var.col] = x_mat[, var.col] 
    }
      noiseXmatrix = newxmatrix
  }
  return(noiseXmatrix)
}

#########################################################################################
