isBestFit = function(x.mat = x, y = y, noiseLevs = noiseLevs, special.Vars = special.Vars, iteration = iteration)
{
  noiseNames = matrix(data = NA, nrow = 1, ncol = dim(x.mat)[2])
  VifLeastSqrsMat = matrix(NA, dim(x.mat)[2], dim(x.mat)[2])
  tolLeastSqrsMat = matrix(NA, dim(x.mat)[2], dim(x.mat)[2])
  wiLeastSqrsMat = matrix(NA, dim(x.mat)[2], dim(x.mat)[2])
  fiLeastSqrsMat = matrix(NA, dim(x.mat)[2], dim(x.mat)[2])
  leamerLeastSqrsMat = matrix(NA, dim(x.mat)[2], dim(x.mat)[2])
  cVifLeastSqrsMat = matrix(NA, dim(x.mat)[2], dim(x.mat)[2])
  
  row.names(VifLeastSqrsMat) = colnames(x.mat)
  row.names(tolLeastSqrsMat) = colnames(x.mat)
  row.names(wiLeastSqrsMat) = colnames(x.mat)
  row.names(fiLeastSqrsMat) = colnames(x.mat)
  row.names(leamerLeastSqrsMat) = colnames(x.mat)
  row.names(cVifLeastSqrsMat) = colnames(x.mat)
  
  for(i in 1:dim(x.mat)[2])
  {
    noiseNames[,i] = paste(colnames(x.mat[i]),".noise", sep="")
  }
  
  colnames(VifLeastSqrsMat) = as.vector(noiseNames)
  colnames(tolLeastSqrsMat) = colnames(VifLeastSqrsMat)
  colnames(wiLeastSqrsMat) = colnames(VifLeastSqrsMat)
  colnames(fiLeastSqrsMat) = colnames(VifLeastSqrsMat)
  colnames(leamerLeastSqrsMat) = colnames(VifLeastSqrsMat)
  colnames(cVifLeastSqrsMat) = colnames(VifLeastSqrsMat)
  
  for(i in 1:dim(x.mat)[2])
  {
    special.Vars = colnames(x.mat)[i]
    summaryTableList = rateOfChange(xmat = x.mat, y = y, noiseLevs = noiseLevs, special.Vars = special.Vars, iteration = iteration)
    
    VifLeastSqrsMat[,i] = summaryTableList[[4]][[3]]
    tolLeastSqrsMat[,i] = summaryTableList[[5]][[3]]
    wiLeastSqrsMat[,i] = summaryTableList[[6]][[3]]
    fiLeastSqrsMat[,i] = summaryTableList[[7]][[3]]
    leamerLeastSqrsMat[,i] = summaryTableList[[8]][[3]]
    cVifLeastSqrsMat[,i] = summaryTableList[[9]][[3]]
  }
  
  diag.names<-c("Vif", "Tol", "Wi", "Fi", "Leamer", "cVIF")
  final.list<-list(VifLeastSqrsMat, tolLeastSqrsMat, wiLeastSqrsMat, fiLeastSqrsMat, leamerLeastSqrsMat, cVifLeastSqrsMat)
  return(structure(final.list, names=diag.names))
  
}
