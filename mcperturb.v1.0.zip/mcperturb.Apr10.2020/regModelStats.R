# ##########################################################################################
# Function Name:
# regModelStats
# 
# Function Descritption:
# Takes an X-matrix of numeric regressors and a numeric response variable, Clculates the 
# regression model and returns a Matix full of summary statistics.
# 
# Function Usage:
# regModelStats(xmat, response)
# 
# Function Arguments:
# xmat        a numeric matrix
# response    a numeric vector
# 
# Function Details:
# The reModelStats funtion calculates a multiple linear regression model lm() and returns a 
# matrix or dataframe of summary statistics The summary statistics include the coefficients, 
# standard errors, and the t-statistics for each parameter. 
# This functin does not call on any functions.
# 
# Function Value:
# This function is used as a supporting function for the mcperturb package
# 
# Function Note:
# This function is made to specifically to return the Lm model summary statistics is a Martix format
# 
# Function Author(s)
# Ryan Zamora, Dr. Shuying Sun
# 
# Function Regerences:
# 
# Function See Also: (other functions)
# 
# Examples:
# 
# # Body dimensions data
# data(body_Dim)
## X-matrix
# x = body_Dim[,c(10, 11, 16, 17, 21, 22, 24)]
# colnames(x) = c("shoulder", "chest", "bicep", "forearm", "wrist", "age", "height")
# regModelStats(Xmat = x,response = y)
#
# #########################################################################################

# Function Definition
regModelStats = function(xmat = c(), response = c())
{
  regModelStatsMat = summary(lm(response ~., data = xmat))$coefficients[2:(dim(xmat)[2]+1), 1:3]
  return(regModelStatsMat)
}

#########################################################################################