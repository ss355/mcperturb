isRateofChange = function(x_mat = x, y = y, noiseLevs = noiseLevs, special.Vars = special.Vars, iteration = iteration)
{
  noiseNames = matrix(data = NA, nrow = 1, ncol = dim(x_mat)[2])
  VifRateOfChangeMat = matrix(NA, dim(x_mat)[2], dim(x_mat)[2])
  tolRateOfChangeMat = matrix(NA, dim(x_mat)[2], dim(x_mat)[2])
  wiRateOfChangeMat = matrix(NA, dim(x_mat)[2], dim(x_mat)[2])
  fiRateOfChangeMat = matrix(NA, dim(x_mat)[2], dim(x_mat)[2])
  leamerRateOfChangeMat = matrix(NA, dim(x_mat)[2], dim(x_mat)[2])
  cVifRateOfChangeMat = matrix(NA, dim(x_mat)[2], dim(x_mat)[2])
  
  row.names(VifRateOfChangeMat) = colnames(x_mat)
  row.names(tolRateOfChangeMat) = colnames(x_mat)
  row.names(wiRateOfChangeMat) = colnames(x_mat)
  row.names(fiRateOfChangeMat) = colnames(x_mat)
  row.names(leamerRateOfChangeMat) = colnames(x_mat)
  row.names(cVifRateOfChangeMat) = colnames(x_mat)
  
  for(i in 1:dim(x_mat)[2])
  {
    noiseNames[,i] = paste(colnames(x_mat[i]),".noise", sep="")
  }
  
  colnames(VifRateOfChangeMat) = as.vector(noiseNames)
  colnames(tolRateOfChangeMat) = colnames(VifRateOfChangeMat)
  colnames(wiRateOfChangeMat) = colnames(VifRateOfChangeMat)
  colnames(fiRateOfChangeMat) = colnames(VifRateOfChangeMat)
  colnames(leamerRateOfChangeMat) = colnames(VifRateOfChangeMat)
  colnames(cVifRateOfChangeMat) = colnames(VifRateOfChangeMat)
  
  
  for(i in 1:dim(x_mat)[2])
  {
    special.Vars = colnames(x_mat)[i]
    summaryTableList = rateOfChange(xmat = x_mat, y = y, noiseLevs = noiseLevs, special.Vars = special.Vars, iteration = iteration)
    
    VifRateOfChangeMat[,i] = summaryTableList[[4]][[4]]
    tolRateOfChangeMat[,i] = summaryTableList[[5]][[4]]
    wiRateOfChangeMat[,i] = summaryTableList[[6]][[4]]
    fiRateOfChangeMat[,i] = summaryTableList[[7]][[4]]
    leamerRateOfChangeMat[,i] = summaryTableList[[8]][[4]]
    cVifRateOfChangeMat[,i] = summaryTableList[[9]][[4]]
  }
  diag.names<-c("Vif", "Tol", "Wi", "Fi", "Leamer", "cVIF")
  final.list<-list(VifRateOfChangeMat, tolRateOfChangeMat, wiRateOfChangeMat, fiRateOfChangeMat, leamerRateOfChangeMat, cVifRateOfChangeMat)
  return(structure(final.list, names=diag.names))
}
