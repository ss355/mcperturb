# ##########################################################################################
# Function Name:
# overallDiagsOut
# 
# Function Descritption:
# The function overallDiagsOut takes an X-matrix of numeric regressors and a numeric 
# response variable, performs perturbation analysis multiple (iter) times for ALL 
# special variables or reressors (all columns in the X-matrix) one by one by calling 
# the function “noiseLevelDigaOutList” to add noise to each variable/regressor. Then 
# within the "noiseLevelDigaOutList", the "omcdiag" function is called to calculate 
# the 6 overall multicollinearity diagnostic measures, which are “Determinant of the 
# correlation matrix |X’X| (Cooley and Lohnes, 1971), “Farrar test of chi-square for 
# presence of multicollinearity (Farrar and Glauber, 1967)”, “Red Indicator 
# (Kovacs et al., 2015) ”, “Sum of lambda inverse values (Chatterjee and Price (1977)”,
#  “Theil's indicator (Theil, 1971)”,  and “condition number (Belsley et al., 1980) ”. 
# This function returns an object with a list of the min.mean, max.mean, and difference
#  (max.mean – min.mean) for each overall diagnostic of each noise variable. 
#
# Function Usage:
# overallDiagsOut = function(xmat = x, y = y, noiseLevs = noiseLevs, iteration = iteration)
# 
# Function Arguments:
# xmat          a numeric matrix or dataframe
# y             a numeric vector
# noiseLevs     a numaric vector or list
# iteration     an interger
# 
# Function Details:
# The overallDiagsOut function provides an oppertunity to look at the overall
# diagnostic measures minimum, maximum, and difference.  
# 
# Function Value:
# This function provides the opertunity for the user to observe the how the overall
#  diagnostics change asnoise is added to each variable.  
# 
# Function Note:
# This function is made to calculate and organize multiple multicollinearity diagnostics 
# and seperated them by diagnostic. 
# This function is dependent on the cran "mctest" package.
# This function calls on the regModeStats function to calculate the regression model 
# statistics,  the mctest::omcdiag function to calculate the overall multicollineatiy 
# diagnost measures,
#
# Function Author(s)
# Ryan Zamora, Dr. Shuying Sun
# 
# Function Regerences:
# 
# Function See Also: (other functions)
# 
# Examples:
# 
# # Body dimensions data
# data(body_Dim)
# # X-matrix
# x = body_Dim[,c(10, 11, 16, 17, 21, 22, 24)]
# colnames(x) = c("shoulder", "chest", "bicep", "forearm", "wrist", "age", "height")
# special.Vars = c("shoulder")
## Making the noiselevels
# noiseStart = 0.05
# noiseEnd = 0.25
# noiseSteps = 0.05
# noiseLevs = seq(noiseStart, noiseEnd, by = noiseSteps)
# iteration = 5
# overallDiagsOut(xmat = x, y = y, noiseLevs = noiseLevs, iteration = iteration)
# 
# #########################################################################################

overallDiagsOut = function(xmat = x, y = y, noiseLevs = noiseLevs, iteration = iteration)
{
  # For this function, "special.Var" is not an argument becasue it will 
  # loop through all variable (one by one)
  
  detMat = matrix(NA, iteration, length(noiseLevs))
  chiSqrMat = matrix(NA, iteration, length(noiseLevs))
  redIndMat = matrix(NA, iteration, length(noiseLevs))
  sumOfLamMat = matrix(NA, iteration, length(noiseLevs))
  theilIndMat = matrix(NA, iteration, length(noiseLevs))
  conditionMat = matrix(NA, iteration, length(noiseLevs))
  
  # Mar 25, 2020 SS notes, in the following 6 code lines, it was "matrix(NA, 7, 4)", 
  # I replaced it with dim(xmat)[2]. The column is "4". These 4 columns are 
  # "Noise.Variable", "min.mean", "max.mean", "max-min difference". Note, becasue
  # "Noise.Variable" is character, so the other 3 columns have "quotation" marks. 
  detoutputMat = matrix(NA, dim(xmat)[2], 4);
  chioutputMat = matrix(NA, dim(xmat)[2], 4)
  redoutputMat = matrix(NA, dim(xmat)[2], 4)
  sumoutputMat = matrix(NA, dim(xmat)[2], 4)
  theiloutputMat = matrix(NA, dim(xmat)[2], 4)
  conditionoutputMat = matrix(NA, dim(xmat)[2], 4)

  colnames(detoutputMat )<-c("Noise.Variable", "min.mean", "max.mean", "max-min")
  colnames(chioutputMat)<- c("Noise.Variable", "min.mean", "max.mean", "max-min")
  colnames(redoutputMat)<- c("Noise.Variable", "min.mean", "max.mean", "max-min")
  colnames(sumoutputMat)<- c("Noise.Variable", "min.mean", "max.mean", "max-min")
  colnames(theiloutputMat )<-c("Noise.Variable", "min.mean", "max.mean", "max-min")
  colnames(conditionoutputMat)<-c("Noise.Variable", "min.mean", "max.mean", "max-min")
    
  outputList = list()
  
  # summaryList = noiseLevelDiagOutList(xmat,y,special.Vars, noiseLevs, iteration)
  for(k in 1:dim(xmat)[2])
  {
    special.Vars = colnames(xmat)[k]
    detoutputMat[k,1] = special.Vars 
    chioutputMat[k,1] = special.Vars 
    redoutputMat[k,1] = special.Vars 
    sumoutputMat[k,1] = special.Vars 
    theiloutputMat[k,1] = special.Vars 
    conditionoutputMat[k,1] = special.Vars
    
    summaryList = noiseLevelDiagOutList(xmat, y, special.Vars, noiseLevs, iteration)
    
    # The output of "noiseLevelDiagOutList" is a "noiselevel + 1" list. 
    # The "1" is for the original data before adding noise. In the following code 
    # "summaryList[[1]][[2]][k= 1:6]", "[[1]]" means it is level 0, i.e., it is based on
    # the orignal data without any noise added to it. "[[2]]" is for "omcdiag" output 
    # with 6 overall diagnostic measures. However, for "j in 2:length(summaryList)", 
    # That is, for level ≥ 2 with "n-iteration" for each noise level, in 
    # "summaryList[[j]][[i]][[2]][1]", this "[[i]]' mean "iteration", and the [[2]]
    # is for "omcdiag" output with 6 overall diagnostic measures. 
    
    origDet = summaryList[[1]][[2]][1]
    origChiSqr = summaryList[[1]][[2]][2]
    origRedInd = summaryList[[1]][[2]][3]
    origSumofLam = summaryList[[1]][[2]][4]
    origTheilInd = summaryList[[1]][[2]][5]
    origCondNum = summaryList[[1]][[2]][6]
    
    for(j in 2:length(summaryList))
    {
      for(i in 1:iteration)
      {
        detMat[i,(j-1)] = summaryList[[j]][[i]][[2]][1]
        chiSqrMat[i,(j-1)] = summaryList[[j]][[i]][[2]][2]
        redIndMat[i,(j-1)] = summaryList[[j]][[i]][[2]][3]
        sumOfLamMat[i,(j-1)] = summaryList[[j]][[i]][[2]][4]
        theilIndMat[i,(j-1)] = summaryList[[j]][[i]][[2]][5]
        conditionMat[i,(j-1)] = summaryList[[j]][[i]][[2]][6]
        
      }
    }
    
    detoutputMat[k,2] = min(apply(detMat, 2, mean), origDet)
    detoutputMat[k,3] = max(apply(detMat, 2, mean), origDet)
    detoutputMat[k,4] = max(apply(detMat, 2, mean), origDet)-min(apply(detMat, 2, mean), origDet)

    chioutputMat[k,2] = min(apply(chiSqrMat, 2, mean), origChiSqr)
    chioutputMat[k,3] = max(apply(chiSqrMat, 2, mean), origChiSqr)
    chioutputMat[k,4] = max(apply(chiSqrMat, 2, mean), origChiSqr)-min(apply(chiSqrMat, 2, mean), origChiSqr)
    
    redoutputMat[k,2] = min(apply(redIndMat, 2, mean), origRedInd)
    redoutputMat[k,3] = max(apply(redIndMat, 2, mean), origRedInd)
    redoutputMat[k,4] = max(apply(redIndMat, 2, mean), origRedInd)-min(apply(redIndMat, 2, mean), origRedInd)
    
    sumoutputMat[k,2] = min(apply(sumOfLamMat, 2, mean), origSumofLam)
    sumoutputMat[k,3] = max(apply(sumOfLamMat, 2, mean), origSumofLam)
    sumoutputMat[k,4] = max(apply(sumOfLamMat, 2, mean), origSumofLam)-min(apply(sumOfLamMat, 2, mean), origSumofLam)
    
    theiloutputMat[k,2] = min(apply(theilIndMat, 2, mean), origTheilInd)
    theiloutputMat[k,3] = max(apply(theilIndMat, 2, mean), origTheilInd)
    theiloutputMat[k,4] = max(apply(theilIndMat, 2, mean), origTheilInd)-min(apply(theilIndMat, 2, mean), origTheilInd)
    
    conditionoutputMat[k,2] = min(apply(conditionMat, 2, mean), origCondNum)
    conditionoutputMat[k,3] = max(apply(conditionMat, 2, mean), origCondNum)
    conditionoutputMat[k,4] = max(apply(conditionMat, 2, mean), origCondNum)-min(apply(conditionMat, 2, mean), origCondNum)
    
    }
 
   ouputlist = list(detoutputMat, chioutputMat, redoutputMat, sumoutputMat, theiloutputMat, conditionoutputMat)  
   ouputlistNames=c("det", "chisquare", "red", "sumOfLambd", "theil", "condi")
   
   return(structure(ouputlist, names= ouputlistNames))

}
#########################################################################################